/*
    ChibiOS - Copyright (C) 2006..2018 Giovanni Di Sirio

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

#include "ch.h"
#include "hal.h"
#include "chprintf.h"
#include "lsm303dlhc.h"

#define cls(chp) chprintf(chp, "\033[2J\033[1;1H")

//declare musical notes
#define DO 1432
#define RE 1275
#define MI 1517
#define FA 1432
#define SOL 1915
#define LA 1700
#define LA2 1136
#define SI 1519
#define SI2 1014
#define g 1275
#define f 1432
#define c 1915
#define d 1700
#define a 1136
#define e 1519
#define b 1014
#define p 1911
#define s 1352
#define v 1073
#define C 956
#define D 852
#define E 758


long christmas[] = {f,a,a,g,f,v,v,a,g,a,C,C,b,C,a,D,C,v,a,g,f,e,a,g,f,f,e,f,0};
long jingle_bells[] = {SI,SI,SI,SI,SI,SI,SI,RE,SOL,LA,SI,DO,DO,DO,DO,DO, SI,SI,SI,SI,LA,LA,SI,LA,RE,0};
long santa_claus[] = {g,e,f,g,g,g,a,b,c,c,c,e,f,g,g,g,a,g,f,f,e,g,c,e,d,f,p,c,0};
int christmas_leds[] = {15,14,14,13,15,12,12,14,13,14,11,11,10,11,14,8,11,12,14,13,15,8,14,13,15,15,10,15};
int jingle_bells_leds[] = {14,14,14,14,14,14,14,8,12,13,14,15,15,15,15,15,14,14,14,14,13,13,14,13,8};
int santa_claus_leds[] = {15,8,10,15,15,15,11,12,13,13,13,8,10,15,15,15,11,15,10,10,8,15,14,8,14,10,14,11};
long christmas_delay[] = {300,450,150,300,300,300,300,300,300,300,300,300,300,900,300,450,150,300,300,300,300,300,300,300,300,300,300,900};
long jingle_bells_delay[] = {200,200,400,200,200,400,200,200,200,200,800,200,200,200,200,200,200,200,200,200,200,200,200,400,200};
long santa_claus_delay[] = {112,112,112,225,225,225,112,112,225,225,225,112,112,225,225,225,112,112,225,450,225,225,225,225,225,450,225,900};

/*===========================================================================*/
/* LSM303DLHC related.                                                       */
/*===========================================================================*/

/* LSM303DLHC Driver: This object represent an LSM303DLHC instance */
static LSM303DLHCDriver LSM303DLHCD1;

static int32_t accraw[LSM303DLHC_ACC_NUMBER_OF_AXES];

static float acccooked[LSM303DLHC_ACC_NUMBER_OF_AXES];

static char axisID[LSM303DLHC_ACC_NUMBER_OF_AXES] = {'X', 'Y', 'Z'};
static uint32_t i;

static const I2CConfig i2ccfg = {
  STM32_TIMINGR_PRESC(15U) |
  STM32_TIMINGR_SCLDEL(4U) | STM32_TIMINGR_SDADEL(2U) |
  STM32_TIMINGR_SCLH(15U)  | STM32_TIMINGR_SCLL(21U),
  0,
  0
};

static const LSM303DLHCConfig lsm303dlhccfg = {
  &I2CD1,
  &i2ccfg,
  NULL,
  NULL,
  LSM303DLHC_ACC_FS_4G,
  LSM303DLHC_ACC_ODR_100Hz,
#if LSM303DLHC_USE_ADVANCED
  LSM303DLHC_ACC_LP_DISABLED,
  LSM303DLHC_ACC_HR_DISABLED,
  LSM303DLHC_ACC_BDU_BLOCK,
  LSM303DLHC_ACC_END_LITTLE,
#endif
  NULL,
  NULL,
  LSM303DLHC_COMP_FS_1P3GA,
  LSM303DLHC_COMP_ODR_30HZ,
#if LSM303DLHC_USE_ADVANCED
  LSM303DLHC_COMP_MD_BLOCK
#endif
};

/*===========================================================================*/
/* Generic code.                                                             */
/*===========================================================================*/

static BaseSequentialStream* chp = (BaseSequentialStream*) &SD1;

//configure pwm
static PWMConfig pwmcfg = {
   1000000,
   100,
   NULL,
   {
      {PWM_OUTPUT_ACTIVE_HIGH, NULL},
      {PWM_OUTPUT_ACTIVE_HIGH, NULL},
      {PWM_OUTPUT_ACTIVE_HIGH, NULL},
      {PWM_OUTPUT_ACTIVE_HIGH, NULL}
   },
   0,
   0
};

//2 threads array are created
thread_t *songs[2];
thread_t *songs_message[2];

//this thread allows you to play the "jingle bells" song continuously, invoking the melody function,
//and is terminated if another thread is to be performed
static THD_WORKING_AREA(jingle_bells_thread,512);
static THD_FUNCTION(jingle_bells_t,arg){
  chRegSetThreadName("Jingle_Bells");
  while(true){
    melody(jingle_bells, jingle_bells_leds, jingle_bells_delay);
  }
}

//this thread allows you to play the "santa claus is coming to town" song continuously, invoking the melody function,
//and is terminated if another thread is to be performed
static THD_WORKING_AREA(santa_claus_thread,512);
static THD_FUNCTION(santa_claus_t,arg){
  chRegSetThreadName("Santa_Claus");
  while(true){
   melody(santa_claus, santa_claus_leds, santa_claus_delay);
  }
}

//this thread allows you to play the "while shephards watched" song continuously, invoking the melody function,
//and is terminated if another thread is to be performed
static THD_WORKING_AREA(christmas_thread,512);
static THD_FUNCTION(christmas_t,arg){
  chRegSetThreadName("Christmas");
  while(true){
   melody(christmas, christmas_leds, christmas_delay);
  }
}

//this thread is the first of the three that is executed when
//the main thread sends it a message, and it plays "jingle bells" song,
//invoking the melody function
static THD_WORKING_AREA(jingle_bells_thread_msg,512);
static THD_FUNCTION(jingle_bells_msg,arg){
  chRegSetThreadName("Jingle_Bells_msg");
  while(true){
    //wait for a message
    thread_t *tp = chMsgWait();
    const char *msg = (const char *)chMsgGet(tp);
    chMsgRelease(tp, MSG_OK);

    melody(jingle_bells, jingle_bells_leds, jingle_bells_delay);
    //finally sends a message to run the next thread
    (void)chMsgSend(songs_message[1],(msg_t)"Santa Claus");
  }
}

//this thread is the second of the three that is executed when
//the previously thread sends it a message, and it plays "santa claus is coming to town" song
//invoking the melody function
static THD_WORKING_AREA(santa_claus_thread_msg,512);
static THD_FUNCTION(santa_claus_msg,arg){
  chRegSetThreadName("Santa_Claus_msg");
  while(true){
    //wait for a message
    thread_t *tp = chMsgWait();
    const char *msg = (const char *)chMsgGet(tp);
    chMsgRelease(tp, MSG_OK);

   melody(santa_claus, santa_claus_leds, santa_claus_delay);

   //finally sends a message to run the next thread
   (void)chMsgSend(songs_message[2],(msg_t)"Christmas");

  }
}

//this thread is the last of the three that is executed when
//the previously thread sends it a message, and it plays "while shephards watched" song,
//invoking the melody function
static THD_WORKING_AREA(christmas_thread_msg,512);
static THD_FUNCTION(christmas_msg,arg){
  chRegSetThreadName("Christmas_msg");
  while(true){
    //wait for a message
    thread_t *tp = chMsgWait();
    const char *msg = (const char *)chMsgGet(tp);
    chMsgRelease(tp, MSG_OK);

   melody(christmas, christmas_leds, christmas_delay);

   //finally sends a message to run the next thread
   //(which is also the first thread that was executed of the three, in this case)
   (void)chMsgSend(songs_message[0],(msg_t)"Jingle Bells");
  }
}

//this thread allows you to acquire the accelerometer data every 100 milliseconds,
//and print them on the terminal
static THD_WORKING_AREA(accelerometer_thread,128);
static THD_FUNCTION(accelerometer,arg){
  chRegSetThreadName("Accelerometer");

  (void*)arg;       //warning remover

    while (true) {
      lsm303dlhcAccelerometerReadRaw(&LSM303DLHCD1, accraw);
      chprintf(chp, "Accelerometer data:\r\n");
      for(i = 0; i < LSM303DLHC_ACC_NUMBER_OF_AXES; i++){
          chprintf(chp, "%c-axis: %d\r\n", axisID[i], accraw[i]);
      }
      lsm303dlhcAccelerometerReadCooked(&LSM303DLHCD1, acccooked);
      chThdSleepMilliseconds(100);

    }
}

//This function enables and disables the pwm channel to play the buzzer,
//and turns on and off the LEDs.
//It is passed as arguments 3 arrays, which are used for songs.
//It also includes the control that allows the thread that is using it to terminate.
int melody(long melodyArray[], int ledArray[], long delayArray[]) {
  int m = 0;
  while(melodyArray[m] != 0){
    m++;
  }
  for(int i = 0; i <= m-1; i++){
    //this is the control to terminate the current thread
    if (chThdShouldTerminateX()) {
            chThdExit(1);
    }
     //start the pwm channel
     pwmStart(&PWMD1, &pwmcfg);
     //change the period for the sound
     pwmChangePeriod(&PWMD1, melodyArray[i]);
     //the pwm channel is enabled
     pwmEnableChannel(&PWMD1, 0, PWM_PERCENTAGE_TO_WIDTH(&PWMD1, 5000));
     //turn on the led
     palWritePad(GPIOE, ledArray[i], PAL_HIGH);
     chThdSleepMilliseconds(delayArray[i]);
     //turn off the led
     palWritePad(GPIOE, ledArray[i], PAL_LOW);
     //the pwm channel is disabled
     pwmDisableChannel(&PWMD1,0);
     chThdSleepMilliseconds(delayArray[i]);
  }
}


int main(void) {

   //drivers and kernels are initialized
   halInit();
   chSysInit();

   sdStart(&SD1, NULL);

   /* LSM303DLHC Object Initialization.*/
   lsm303dlhcObjectInit(&LSM303DLHCD1);
   lsm303dlhcStart(&LSM303DLHCD1, &lsm303dlhccfg);

   chThdCreateStatic(accelerometer_thread, sizeof(accelerometer_thread), NORMALPRIO +1, accelerometer, NULL);

   //the PE9 pin is set to pwm mode
   palSetPadMode(GPIOE, 9, PAL_MODE_ALTERNATE(2));

   palSetPadMode(GPIOE, 8, PAL_MODE_OUTPUT_PUSHPULL);
   palSetPadMode(GPIOE, 10, PAL_MODE_OUTPUT_PUSHPULL);
   palSetPadMode(GPIOE, 11, PAL_MODE_OUTPUT_PUSHPULL);
   palSetPadMode(GPIOE, 12, PAL_MODE_OUTPUT_PUSHPULL);
   palSetPadMode(GPIOE, 13, PAL_MODE_OUTPUT_PUSHPULL);
   palSetPadMode(GPIOE, 14, PAL_MODE_OUTPUT_PUSHPULL);
   palSetPadMode(GPIOE, 15, PAL_MODE_OUTPUT_PUSHPULL);
   palWritePad(GPIOE, 8, PAL_LOW);
   for(int i = 10; i <= 15; i++){
     palWritePad(GPIOE, i, PAL_LOW);
   }
   //this variable indicates which thread must be terminate when another thread is executed
   int active_thread = 0;

   songs_message[1] = chThdCreateStatic(santa_claus_thread_msg, sizeof(santa_claus_thread_msg), NORMALPRIO +1, santa_claus_msg, NULL);
   songs_message[2] = chThdCreateStatic(christmas_thread_msg, sizeof(christmas_thread_msg), NORMALPRIO +1, christmas_msg, NULL);

   /**this while every 300 milliseconds checks where the card is located
      (using the accelerometer data) and if the user button is pressed,
      depending on the position, a specific thread is executed, and the previous one is terminated.
   **/
   while(true){

       if(accraw[0] > -3000 && accraw[0]< 3000 && accraw[1] < 3000 && accraw[1] > -3000 && palReadPad(GPIOA, GPIOA_BUTTON)){

         switch(active_thread){
           case 1: chThdTerminate(songs[0]);
                   chThdWait(songs[0]);

                   chprintf(chp, "Terminato thread jingle bells:\r\n");
                   break;
           case 2: chThdTerminate(songs[1]);
                   chThdWait(songs[1]);

                   chprintf(chp, "Terminato thread santa claus:\r\n");
                   break;
           case 3: chThdTerminate(songs[2]);
                   chThdWait(songs[2]);

                   chprintf(chp, "Terminato thread christmas:\r\n");
                   break;

           case 4: chThdTerminate(songs_message[0]);
                   chThdWait(songs_message[0]);
                   break;

           default: break;
         }
         songs[0] = chThdCreateStatic(jingle_bells_thread, sizeof(jingle_bells_thread), NORMALPRIO +1, jingle_bells_t, NULL);

         active_thread = 1;
         chprintf(chp, "attivato jingle bells\r\n");
       }
       if(accraw[0] > -3000 && accraw[0]< 3000 && accraw[1] > 3000 && palReadPad(GPIOA, GPIOA_BUTTON)){
         switch(active_thread){
           case 1: chThdTerminate(songs[0]);
           chThdWait(songs[0]);

                   chprintf(chp, "Terminato thread jingle bells:\r\n");
                   break;
           case 2: chThdTerminate(songs[1]);
                   chThdWait(songs[1]);

                   chprintf(chp, "Terminato thread santa claus:\r\n");
                   break;
           case 3: chThdTerminate(songs[2]);
                   chThdWait(songs[2]);

                   chprintf(chp, "Terminato thread christmas:\r\n");
                   break;

           case 4: chThdTerminate(songs_message[0]);
                   chThdWait(songs_message[0]);
                   break;
           default: break;
         }
         songs[1] = chThdCreateStatic(santa_claus_thread, sizeof(santa_claus_thread), NORMALPRIO +1, santa_claus_t, NULL);
         active_thread = 2;
         chprintf(chp, "attivato santa claus\r\n");
       }
       if(accraw[0] > -3000 && accraw[0]< 3000 && accraw[1] < -3000  && palReadPad(GPIOA, GPIOA_BUTTON)){
         switch(active_thread){
           case 1: chThdTerminate(songs[0]);
                   chThdWait(songs[0]);

                   chprintf(chp, "Terminato thread jingle bells:\r\n");
                   break;
           case 2: chThdTerminate(songs[1]);
                   chThdWait(songs[1]);

                   chprintf(chp, "Terminato thread santa claus:\r\n");
                   break;
           case 3: chThdTerminate(songs[2]);
                   chThdWait(songs[2]);

                   chprintf(chp, "Terminato thread christmas:\r\n");
                   break;
           case 4: chThdTerminate(songs_message[0]);
                   chThdWait(songs_message[0]);
                   break;
           default: break;
         }
         songs[2] = chThdCreateStatic(christmas_thread, sizeof(christmas_thread), NORMALPRIO +1, christmas_t, NULL);
         active_thread = 3;
         chprintf(chp, "attivato christmas\r\n");
       }
       if(accraw[0] >3000 && accraw[1] > -3000  && accraw[1] < 3000  && palReadPad(GPIOA, GPIOA_BUTTON)){

         switch(active_thread){
                   case 1: chThdTerminate(songs[0]);
                           chThdWait(songs[0]);

                           chprintf(chp, "Terminato thread jingle bells:\r\n");
                           break;
                   case 2: chThdTerminate(songs[1]);
                           chThdWait(songs[1]);

                           chprintf(chp, "Terminato thread santa claus:\r\n");
                           break;
                   case 3: chThdTerminate(songs[2]);
                           chThdWait(songs[2]);

                           chprintf(chp, "Terminato thread christmas:\r\n");
                           break;
                   case 4: chThdTerminate(songs_message[0]);
                           chThdWait(songs_message[0]);
                           break;
                   default: break;
                 }
         songs_message[0] = chThdCreateStatic(jingle_bells_thread_msg, sizeof(jingle_bells_thread_msg), NORMALPRIO +1, jingle_bells_msg, NULL);
         active_thread = 4;
         (void)chMsgSend(songs_message[0],(msg_t)"Jingle Bells");
        }

       chThdSleepMilliseconds(300);

   }

   //turn off the accelerometer
   lsm303dlhcStop(&LSM303DLHCD1);

  cls(chp);
  return 0;
}

